﻿namespace eCommerceApp.Application.DTOs.Identity
{
    public class BaseModel
    {
        public required string Email { get; set; }
        public required string Password { get; set; }
    }
}
