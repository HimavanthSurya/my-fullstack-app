﻿namespace eCommerceApp.Application.DTOs.Identity
{
    public class LoginUser : BaseModel
    {

    }
}
