﻿

namespace eCommerceApp.Application.DTOs.Product
{
    public class CreateProduct : ProductBase
    {
       
    }
}
