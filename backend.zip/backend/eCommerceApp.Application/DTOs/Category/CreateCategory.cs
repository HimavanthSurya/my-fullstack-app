﻿namespace eCommerceApp.Application.DTOs.Category
{
    public class CreateCategory : CategoryBase
    {
    }
}
